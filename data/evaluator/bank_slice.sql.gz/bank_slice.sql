-- Evaluator bank.* slice (infra/evaluator_pack.py).
-- source: synthetic
-- Loaded by Postgres from /docker-entrypoint-initdb.d/ on an empty volume.
create schema if not exists bank;
create schema if not exists ops;
create table bank.customers (
  customer_id text primary key,
  first_name text,
  country text,
  segment text,
  customer_status text,
  detected_accent text
);
insert into bank.customers (customer_id, first_name, country, segment, customer_status, detected_accent) values
  ('CLI-EVAL-D09-01', 'Eval1', 'Mexico', 'Mass', 'Active', 'mexican'),
  ('CLI-EVAL-D01-02', 'Eval2', 'Mexico', 'Mass', 'Active', 'mexican'),
  ('CLI-EVAL-D02-03', 'Eval3', 'Mexico', 'Mass', 'Active', 'mexican'),
  ('CLI-EVAL-D06-04', 'Eval4', 'Mexico', 'Mass', 'Active', 'mexican'),
  ('CLI-EVAL-D07-05', 'Eval5', 'Mexico', 'Mass', 'Active', 'mexican'),
  ('CLI-EVAL-D08-06', 'Eval6', 'Mexico', 'Mass', 'Active', 'mexican'),
  ('CLI-EVAL-D05-07', 'Eval7', 'Mexico', 'Mass', 'Active', 'mexican');
create table bank.products (
  product_id text primary key,
  customer_id text not null,
  product_type text,
  is_card boolean,
  product_number_last4 text,
  currency text,
  product_status text,
  opening_date date,
  expiration_date date,
  has_linked_app boolean
);
insert into bank.products (product_id, customer_id, product_type, is_card, product_number_last4, currency, product_status, opening_date, expiration_date, has_linked_app) values
  ('PRD-EVAL-D09-01', 'CLI-EVAL-D09-01', 'Credit Card', TRUE, '4242', 'USD', 'Active', '2024-01-01', '2028-01-01', TRUE),
  ('PRD-EVAL-D01-02', 'CLI-EVAL-D01-02', 'Credit Card', TRUE, '4242', 'USD', 'Active', '2024-01-01', '2028-01-01', TRUE),
  ('PRD-EVAL-D02-03', 'CLI-EVAL-D02-03', 'Credit Card', TRUE, '4242', 'USD', 'Active', '2024-01-01', '2028-01-01', TRUE),
  ('PRD-EVAL-D06-04', 'CLI-EVAL-D06-04', 'Credit Card', TRUE, '4242', 'USD', 'Active', '2024-01-01', '2028-01-01', TRUE),
  ('PRD-EVAL-D07-05', 'CLI-EVAL-D07-05', 'Credit Card', TRUE, '4242', 'USD', 'Active', '2024-01-01', '2028-01-01', TRUE),
  ('PRD-EVAL-D08-06', 'CLI-EVAL-D08-06', 'Credit Card', TRUE, '4242', 'USD', 'Active', '2024-01-01', '2028-01-01', TRUE),
  ('PRD-EVAL-D05-07', 'CLI-EVAL-D05-07', 'Credit Card', TRUE, '4242', 'USD', 'Active', '2024-01-01', '2028-01-01', TRUE);
create table bank.transactions (
  transaction_id text primary key,
  customer_id text not null,
  product_id text not null,
  transaction_date timestamp,
  process_date date,
  transaction_type text,
  transaction_category text,
  amount numeric,
  currency text,
  amount_usd numeric not null,
  amount_usd_source text not null,
  channel text,
  merchant_name text,
  merchant_category text,
  transaction_country text,
  transaction_city text,
  transaction_status text,
  response_code text,
  is_fraud boolean,
  fraud_score numeric
);
insert into bank.transactions (transaction_id, customer_id, product_id, transaction_date, process_date, transaction_type, transaction_category, amount, currency, amount_usd, amount_usd_source, channel, merchant_name, merchant_category, transaction_country, transaction_city, transaction_status, response_code, is_fraud, fraud_score) values
  ('TRX-EVAL-D09-01', 'CLI-EVAL-D09-01', 'PRD-EVAL-D09-01', '2026-06-10 12:00:00', '2026-06-10', 'Purchase', 'Retail', 25.37, 'USD', 25.37, 'native_usd', 'POS', 'Farmacias del Ahorro', 'Retail', 'Mexico', 'CDMX', 'Approved', '00', FALSE, 1.0),
  ('TRX-EVAL-D01-02', 'CLI-EVAL-D01-02', 'PRD-EVAL-D01-02', '2026-06-08 12:00:00', '2026-06-08', 'Purchase', 'Retail', 40.00, 'USD', 40.00, 'native_usd', 'POS', 'Super Ahorro', 'Retail', 'Mexico', 'CDMX', 'Declined', '00', FALSE, 1.0),
  ('TRX-EVAL-D02-03', 'CLI-EVAL-D02-03', 'PRD-EVAL-D02-03', '2026-06-05 12:00:00', '2026-06-05', 'Purchase', 'Retail', 18.50, 'USD', 18.50, 'native_usd', 'POS', 'Cafe Central', 'Retail', 'Mexico', 'CDMX', 'Reversed', '00', FALSE, 1.0),
  ('TRX-EVAL-D06-04', 'CLI-EVAL-D06-04', 'PRD-EVAL-D06-04', '2026-06-10 12:00:00', '2026-06-10', 'Purchase', 'Retail', 25.00, 'USD', 25.00, 'native_usd', 'POS', 'Cafe', 'Retail', 'Mexico', 'CDMX', 'Approved', '00', FALSE, 1.0),
  ('TRX-EVAL-D07-05', 'CLI-EVAL-D07-05', 'PRD-EVAL-D07-05', '2026-06-01 12:00:00', '2026-06-01', 'Purchase', 'Retail', 750.00, 'USD', 750.00, 'native_usd', 'POS', 'Electrónica Sur', 'Retail', 'Mexico', 'CDMX', 'Approved', '00', FALSE, 1.0),
  ('TRX-EVAL-D08-06', 'CLI-EVAL-D08-06', 'PRD-EVAL-D08-06', '2026-05-20 12:00:00', '2026-05-20', 'Purchase', 'Retail', 55.00, 'USD', 55.00, 'native_usd', 'POS', 'Mercado Norte', 'Retail', 'Mexico', 'CDMX', 'Approved', '00', FALSE, 1.0),
  ('TRX-EVAL-D05-07', 'CLI-EVAL-D05-07', 'PRD-EVAL-D05-07', '2025-12-01 12:00:00', '2025-12-01', 'Purchase', 'Retail', 90.00, 'USD', 90.00, 'native_usd', 'POS', 'Hotel Sol', 'Retail', 'Mexico', 'CDMX', 'Approved', '00', FALSE, 1.0);
create table bank.customer_complaint_stats (
  customer_id text primary key,
  complaints_total bigint,
  complaints_last_90d bigint,
  last_complaint_at timestamp,
  is_repeat_complainer boolean
);
insert into bank.customer_complaint_stats (customer_id, complaints_total, complaints_last_90d, last_complaint_at, is_repeat_complainer) values
  ('CLI-EVAL-D09-01', 0, 0, NULL, FALSE),
  ('CLI-EVAL-D01-02', 0, 0, NULL, FALSE),
  ('CLI-EVAL-D02-03', 0, 0, NULL, FALSE),
  ('CLI-EVAL-D06-04', 0, 0, NULL, FALSE),
  ('CLI-EVAL-D07-05', 0, 0, NULL, FALSE),
  ('CLI-EVAL-D08-06', 3, 2, '2026-05-01 10:00:00', TRUE),
  ('CLI-EVAL-D05-07', 0, 0, NULL, FALSE);
create table bank.resolution_benchmarks (
  category text,
  priority text,
  cases bigint,
  resolved_cases bigint,
  median_resolution_days double precision,
  p75_resolution_days double precision,
  sla_breach_rate double precision,
  rejection_rate double precision,
  primary key (category, priority)
);
insert into bank.resolution_benchmarks (category, priority, cases, resolved_cases, median_resolution_days, p75_resolution_days, sla_breach_rate, rejection_rate) values
  ('Dispute', 'all', 100, 40, 15.5, 22.0, 0.2, 0.01),
  ('all', 'all', 1000, 400, 12.0, 18.0, 0.15, 0.02);
create table bank.dispute_scenarios (
  rule_id text,
  customer_says_not_me boolean,
  transaction_id text,
  route text,
  offer_card_block boolean,
  customer_id text not null,
  transaction_status text,
  transaction_date timestamp,
  days_before_as_of integer,
  amount_usd numeric,
  is_fraud boolean,
  fraud_score numeric,
  is_repeat_complainer boolean,
  primary key (rule_id, customer_says_not_me, transaction_id)
);
insert into bank.dispute_scenarios (rule_id, customer_says_not_me, transaction_id, route, offer_card_block, customer_id, transaction_status, transaction_date, days_before_as_of, amount_usd, is_fraud, fraud_score, is_repeat_complainer) values
  ('D09-eligible', FALSE, 'TRX-EVAL-D09-01', 'open_dispute', FALSE, 'CLI-EVAL-D09-01', 'Approved', '2026-06-10 12:00:00', 8, 25.37, FALSE, 1.0, FALSE),
  ('D01-declined-not-charged', FALSE, 'TRX-EVAL-D01-02', 'inform', FALSE, 'CLI-EVAL-D01-02', 'Declined', '2026-06-08 12:00:00', 10, 40.00, FALSE, 1.0, FALSE),
  ('D02-already-reversed', FALSE, 'TRX-EVAL-D02-03', 'inform', FALSE, 'CLI-EVAL-D02-03', 'Reversed', '2026-06-05 12:00:00', 13, 18.50, FALSE, 1.0, FALSE),
  ('D06-possible-fraud', TRUE, 'TRX-EVAL-D06-04', 'escalate_fraud', TRUE, 'CLI-EVAL-D06-04', 'Approved', '2026-06-10 12:00:00', 8, 25.00, FALSE, 1.0, FALSE),
  ('D07-above-auto-limit', FALSE, 'TRX-EVAL-D07-05', 'escalate_agent', FALSE, 'CLI-EVAL-D07-05', 'Approved', '2026-06-01 12:00:00', 17, 750.00, FALSE, 1.0, FALSE),
  ('D08-repeat-complainer', FALSE, 'TRX-EVAL-D08-06', 'escalate_agent', FALSE, 'CLI-EVAL-D08-06', 'Approved', '2026-05-20 12:00:00', 29, 55.00, FALSE, 1.0, TRUE),
  ('D05-outside-window', FALSE, 'TRX-EVAL-D05-07', 'refuse', FALSE, 'CLI-EVAL-D05-07', 'Approved', '2025-12-01 12:00:00', 199, 90.00, FALSE, 1.0, FALSE);
create table ops.load_runs (
  run_id text not null,
  loaded_at timestamptz not null,
  table_name text not null,
  row_count bigint not null,
  git_sha text,
  primary key (run_id, table_name)
);
insert into ops.load_runs (run_id, loaded_at, table_name, row_count, git_sha) values
  ('evaluator-pack', '2026-06-18 00:00:00', 'customers', 7, NULL),
  ('evaluator-pack', '2026-06-18 00:00:00', 'products', 7, NULL),
  ('evaluator-pack', '2026-06-18 00:00:00', 'transactions', 7, NULL),
  ('evaluator-pack', '2026-06-18 00:00:00', 'customer_complaint_stats', 7, NULL),
  ('evaluator-pack', '2026-06-18 00:00:00', 'resolution_benchmarks', 2, NULL),
  ('evaluator-pack', '2026-06-18 00:00:00', 'dispute_scenarios', 7, NULL);
create index transactions_customer_date on bank.transactions (customer_id, transaction_date desc);
create index products_customer on bank.products (customer_id);
create index dispute_scenarios_customer on bank.dispute_scenarios (customer_id);
